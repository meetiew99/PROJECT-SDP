# ESP32-Water-Turbidity
IoT Water Turbidity Monitor by Server Hosting in ESP32

#Turbidity - ESP32 connections 

VCC        - Vin

GND        - GND

OUT        - GPIO36
