# ESP32-DHT-Webserver
This Project is an ESP32 web server with the DHT11 or DHT22 sensor that displays temperature and humidity. The web server updates the readings automatically without the need to refresh the web page.
